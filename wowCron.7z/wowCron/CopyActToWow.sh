cd /home/user/WoWCronJob/
/usr/bin/java -classpath :commons-logging-1.1.jar:dom4j-1.6.1.jar:mail-1.4.jar:mysql-connector-java-5.1.9.jar:poi-3.8-20120326.jar:poi-examples-3.8-20120326.jar:poi-excelant-3.8-20120326.jar:poi-ooxml-3.8-20120326.jar:poi-ooxml-schemas-3.8-20120326.jar:poi-scratchpad-3.8-20120326.jar:xmlbeans-2.4.0.jar:org.apache.commons.collections.jar: CopyActToWowOriginal
