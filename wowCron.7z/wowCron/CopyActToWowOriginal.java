import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class CopyActToWowOriginal{
    public static void main(String[] args){	
 		
 		Connection wowConn = null;
 		Connection actConn = null;
 		PreparedStatement ps ;
 		PreparedStatement ps1 ;
 		CallableStatement callableStatement = null;
 	
 		ResultSet rs = null;		
		String timeStamp = ""; 		 		
 	  
 		try {

			System.setOut(new PrintStream(new FileOutputStream("CopyActToWow.log"), true));

			timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm").format(Calendar.getInstance().getTime());

 			System.out.println("Start Time "+timeStamp);

 			Class.forName("com.mysql.jdbc.Driver");

 			wowConn = DriverManager.getConnection("jdbc:mysql://10.11.2.26:3306/wow_pmo", "mysql","Mysql@123");
 			
 			actConn = DriverManager.getConnection("jdbc:mysql://52.21.15.222:3306/actitime", "actitime","password");
                        
                        System.out.println("actConn is : "+actConn);
 			
 			ps= wowConn.prepareStatement("delete from tt_record_x where user_id not in (0)");
 			
 			ps.executeUpdate();
 			
 			ps= wowConn.prepareStatement("insert into tt_record_x (user_id,task_id,record_date,actuals,created_date) select user_id,task_id,record_date,actuals,curdate() from tt_record ");
 			
 			ps.executeUpdate();
 			
 			ps= wowConn.prepareStatement("delete from tt_record where user_id not in (0)");
 			
 			ps.executeUpdate();
 			
 			
 			
 			ps = actConn.prepareStatement("select * from tt_record where record_date >='2017-12-01'");
                       //ps = actConn.prepareStatement("select * from tt_record where record_date<='2017-04-08'");

 			
 			rs = ps.executeQuery();
 		
 			System.out.println("Copying tt_record");
 			int m =0;
 			while(rs.next()){ 
 				System.out.println("inserting "+ m++);
 				ps1 = wowConn.prepareStatement(" insert into tt_record (user_id,task_id,record_date,actuals)values(?,?,?,?) ");
 				ps1.setInt(1, rs.getInt(1));
 				ps1.setInt(2, rs.getInt(2));
 				ps1.setDate(3, rs.getDate(3));
 				ps1.setInt(4, rs.getInt(4));
 				ps1.executeUpdate();
 				ps1.close();
 			}
 			 
 			
 			
 			ps= wowConn.prepareStatement("delete from task_x where id not in (0)");
 			
 			ps.executeUpdate();
 			
 			ps= wowConn.prepareStatement("insert into task_x (id,customer_id,project_id,create_timestamp,completion_date,last_tt_date,name,name_lower,"
 					+ "description,deadline_date,billing_type_id,budget,created_date) select id,customer_id,project_id,create_timestamp,completion_date,last_tt_date,name,name_lower,"
 					+ "description,deadline_date,billing_type_id,budget,curdate() from task ");
 			
 			ps.executeUpdate();
 			
 			ps= wowConn.prepareStatement("delete from task where id not in (0)");
 			
 			ps.executeUpdate();
 			 
 			
 			ps = actConn.prepareStatement("select * from task ");
 			
 			rs = ps.executeQuery();
 			int i =0 ;
 			System.out.println("Copying task");
 			while(rs.next()){
 			 System.out.println("inserting task "+ i++);
 				ps1 = wowConn.prepareStatement(" insert into task (id,customer_id,project_id,create_timestamp,completion_date,last_tt_date,name,name_lower,"
 					+ "description,deadline_date,billing_type_id,budget)values(?,?,?,?,?,?,?,?,?,?,?,?) ");
 				ps1.setInt(1, rs.getInt(1));
 				ps1.setInt(2, rs.getInt(2));
 				ps1.setInt(3, rs.getInt(3));
 				
 				ps1.setDate(4,rs.getDate(4));
 				
 				ps1.setDate(5,rs.getDate(5));
 				ps1.setDate(6,rs.getDate(6));
 				
 				ps1.setString(7, rs.getString(7));
 				ps1.setString(8, rs.getString(8));
 				ps1.setString(9, rs.getString(9));
 				
 				ps1.setDate(10, rs.getDate(10));
 				ps1.setInt(11, rs.getInt(11));
 				ps1.setInt(12, rs.getInt(12));
 				
 				ps1.executeUpdate();
 				ps1.close();
 			}
 			
 			
 			ps= wowConn.prepareStatement("select MAX(id) from l_customer");
 			rs = ps.executeQuery();
 			
 			String maxCount2 ="0";
 			while(rs.next()){
 				maxCount2 = rs.getString(1);
 				System.out.println("\nMax count l_customer WOW "+maxCount2);
 			}
 			
 		  
 			ps1= actConn.prepareStatement("select create_timestamp, name, name_lower, description, archiving_timestamp,id "
 					+ " from customer where id > "+maxCount2+" order by 1 asc ");
 			
 			rs = ps1.executeQuery();
 			
 			System.out.println("Copying customers");
 			int l=0;
 			while(rs.next()){
 				l++;
 				ps = wowConn.prepareStatement(" insert into l_customer (create_timestamp, name, name_lower, description, archiving_timestamp,id) "
 						+ " values(?,?,?,?,?,?) ");
 				
 				ps.setDate(1,rs.getDate(1));
 				ps.setString(2, rs.getString(2));
 				ps.setString(3, rs.getString(3));
 				ps.setString(4, rs.getString(4));
 				ps.setDate(5,rs.getDate(5)); 
 				ps.setInt(6, rs.getInt(6));
 				ps.executeUpdate();
 			}
 			System.out.println(""+l+" customer reocrds inserted");
 			ps.close();
 			 
 			
 			ps= wowConn.prepareStatement("select MAX(id) from l_project");
 			rs = ps.executeQuery();
 			
 			String maxCount ="0";
 			while(rs.next()){
 				maxCount = rs.getString(1);
 				System.out.println("\nMax count l_project WOW "+maxCount);
 			}
 			
 			ps1= actConn.prepareStatement("select customer_id,create_timestamp,name,name_lower,description,archiving_timestamp,id "
 					+ " from project where id > "+maxCount+" order by 3 asc ");
 			rs = ps1.executeQuery();
 			
 			System.out.println("Copying project");
 			int j=0;
 			while(rs.next()){
 				j++;
 				ps = wowConn.prepareStatement(" insert into l_project (customer_id,create_timestamp,name,name_lower,description,archiving_timestamp,id)values(?,?,?,?,?,?,?) ");
 				
 				ps.setInt(1, rs.getInt(1));
 				ps.setDate(2,rs.getDate(2));
 				ps.setString(3, rs.getString(3));
 				ps.setString(4, rs.getString(4));
 				ps.setString(5, rs.getString(5));
 				ps.setDate(6,rs.getDate(6));
 				ps.setInt(7, rs.getInt(7));
 				
 			    ps.executeUpdate();
 			}
 			System.out.println(""+j+" project records inserted");
 			ps.close();
 			
 			
 			
 			ps= wowConn.prepareStatement("select MAX(id) from l_employee where id<100000");
 			rs = ps.executeQuery();
 			
 			String maxCount1 ="0";
 			while(rs.next()){
 				maxCount1 = rs.getString(1);
 				System.out.println("\nMax count l_employee WOW "+maxCount1);
 			}
 			
 			
 			ps1= actConn.prepareStatement("select username, username_lower, md5_password, first_name, middle_name,"
 						+ " last_name, email, phone ,  fax ,  mobile ,"
 						+ "  other_contact ,  is_enabled ,  workday_duration ,  overtime_tracking , overtime_level ,  is_locked , hire_date ,release_date,  all_projects_assigned,id "
 					+ " from at_user where id > "+maxCount1+" order by 1 asc ");
 			rs = ps1.executeQuery();
 			System.out.println("Copying employees");
 			int k=0;
 			while(rs.next()){
 				k++;
 				ps = wowConn.prepareStatement(" insert into l_employee (username, username_lower, md5_password, first_name, middle_name,"
 						+ " last_name, email, phone ,  fax ,  mobile ,"
 						+ "  other_contact ,  is_enabled ,  workday_duration ,  overtime_tracking , overtime_level ,"
 						+ "  is_locked , hire_date ,release_date, all_projects_assigned,id,Is_Active)values(?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,?) ");
 				
 				ps.setString(1, rs.getString(1));
 				ps.setString(2, rs.getString(2));
 				ps.setString(3, rs.getString(3));
 				ps.setString(4, rs.getString(4));
 				ps.setString(5, rs.getString(5));
 				ps.setString(6, rs.getString(6));
 				ps.setString(7, rs.getString(7));
 				ps.setString(8, rs.getString(8));
 				ps.setString(9, rs.getString(9));
 				ps.setString(10, rs.getString(10));
 				ps.setString(11, rs.getString(11));
 				
 				ps.setInt(12, rs.getInt(12));
 				ps.setInt(13, rs.getInt(13));
 				ps.setInt(14, rs.getInt(14));
 				ps.setInt(15, rs.getInt(15));
 				ps.setInt(16, rs.getInt(16));
 				ps.setString(17,rs.getString(17));
 				ps.setString(18,rs.getString(18));
 				ps.setInt(19, rs.getInt(19)); 
 				ps.setInt(20, rs.getInt(20));
 				ps.setInt(21, 1); //is Active status
 				
 			    ps.executeUpdate();
 			}
 			System.out.println(""+k+" employee records inserted");
 			ps.close();                                               

 			String getWeekdatesFor3Mnts = "{call getWeekdatesFor3Mnts()}";
 			
 			callableStatement = wowConn.prepareCall(getWeekdatesFor3Mnts);
 			callableStatement.executeUpdate();
 			
			timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm").format(Calendar.getInstance().getTime());
 			System.out.println("\nEnd Time "+timeStamp);
				
 		} catch (Exception e1) {
 			System.out.println(e1.getMessage());
 			e1.printStackTrace();
 		} 
 	 		
 	}
}
