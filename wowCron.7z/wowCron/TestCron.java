import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author imohammed
 */

public class TestCron{
    public static void main(String[] args) {
 	 		
 		Connection wowConn = null;
 		PreparedStatement ps;
 		CallableStatement callableStatement = null; 		 		
 	  
 		try {
			System.out.println("bfore..");

			System.setOut(new PrintStream(new FileOutputStream("CopyActToWow.log"), true));

			String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm").format(Calendar.getInstance().getTime());

 			System.out.println("Start Time "+timeStamp);

 			Class.forName("com.mysql.jdbc.Driver");

 			wowConn = DriverManager.getConnection("jdbc:mysql://10.11.2.26:3306/wow_pmo_test", "pmo","PmoPassword!23"); 			
 			
			//ps = wowConn.prepareStatement("update b_workbook set Workbook_Name='ID Systems Test' where B_Workbook_Id=446");

			//ps.executeUpdate();

			//String TestCronJobProc = "{call TestCronJobProc()}";
 			
 			//callableStatement = wowConn.prepareCall(TestCronJobProc);

 			//callableStatement.executeUpdate();

			timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm").format(Calendar.getInstance().getTime());

 			System.out.println("End Time "+timeStamp);

			
 		} catch (Exception e1) {
 			System.out.println(e1.getMessage());
 			e1.printStackTrace();
 		}
 	 		
 	}
}
